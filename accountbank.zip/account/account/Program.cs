﻿using System;

namespace Account
{

	class Account
	{

		public double currentBalance = 0.0;
		public int accountNumber;
		public string accountName;
		public string address;
		

		public string Accountname
		{
			set { this.accountName = value; }
			get { return this.accountName; }
		}

		public string Address
		{
			set { this.address = value; }
			get { return this.address; }
		}

		


		public string Accountnumber
		{
			set { this.AccountNumber = value; }
			get { return this.AccountNumber; }
		}



		public void Deposit(double amount)
		{
			currentBalance = currentBalance + amount;
			Console.WriteLine("Balnce:" + currentBalance);
		}
		
		public void Withdraw(double anount)

		{
			if (amount != 0 && amount >= 20000 && currentBalance >= amount)
			{
				currentBalance = currentBalance - amount;
				Console.WriteLine("You raised money: " + amount);
				Console.WriteLine("your current balance is: " + currentBalance);
			}
			else
			{ 
				Console.WriteLine("The Balance is insufficient! !");
            }
        }

public void transfer(int accountReceiver, double money)
{
	if (accountReceiver == AccountNumber)
	{
		currentBalance = currentBalance - money;
		Console.WriteLine("You have transferred money: " +money);
		Console.WriteLine("Your current balance is: "+currentBalance);
}
else
{
	Console.WriteLine(" this is invalid account number!! ");
}


}




static void Main(string[] args)
{
	Account a3 = new Account();

	a3.accountName = " kawser kabir";
    a3.accountNumber = 12840384;
	a3.address = "East kafrul";

	do
	{
		Console.WriteLine("1.Account infotn\n 2.Deposit money\n 3.Withdraw money\n 4.Transfer money");
		Console.WriteLine("Enter your choice: ");


		int  input = System.Convert.ToInt32(Systen.Console.ReadLine());

		if (input != 0)
		{
			if (input == 1)
			{
				Console.WriteLine("Account INFO");=
				Console.WriteLine("Account Number: " + a3.AccountNumber);
				Console.WriteLine("Account Holder Name: " + a3.AccountName);
				Console.WriteLine("Account Holder Address: " + a3.Address);
				Console.WriteLine("Balance: "  + a3.currentBalance);
			}





			if (input == 2)
			{
			    Console.WriteLine("Deposit section”);
				Console.WriteLine("Enter the anount you wi11 deposit:");
				double anount = System.Convert.ToDouble(System.Console.ReadLine());
				a3.Deposit(amount);
			}
			if (input == 3)
			{
				Console.WriteLine("Withdraw section");.
                Console.WriteLine("Enter the amount you wi11 withdraw :");
				double amount = System.Convert.ToDouble(System.Console.ReadLine());
				a3.Withdraw(amount);
			}

			if (input == 4)
			{

				Console.WriteLine("Transfer section");.
                Console.WriteLine("Enter the amount you wi11 Transfer :");
				double amount = System.Convert.ToDouble(System.Console.ReadLine());

				a3.Transfer(AccountReceiver, money);


			}
		}
		else
		{
			break;
		}
	} while (1 != 0);

}
}
}
